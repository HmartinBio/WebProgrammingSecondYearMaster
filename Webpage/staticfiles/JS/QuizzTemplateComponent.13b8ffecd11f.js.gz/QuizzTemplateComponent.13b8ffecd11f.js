$(document).ready(function(){
    $("#username").css({'left': '88.5%', 
    'overflow': 'hidden',
    'text-overflow': 'ellipsis'});

    $(".firstQuestion").css({'position': 'absolute', 'top': '17%'});
    $(".secondQuestion").css({'position': 'absolute', 'top': '100%'});
    $(".thirdQuestion").css({'position': 'absolute', 'top': '185%'});
    $(".fourthQuestion").css({'position': 'absolute', 'top': '270%'});

    $("button[type='submit']").css({'position': 'absolute', 'top': '353%'});

});