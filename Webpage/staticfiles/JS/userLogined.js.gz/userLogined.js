$(document).ready(function(){
    $(".quizz").css({'left': '22%'});
    $("#username").css({'left': '88%', 
    'overflow': 'hidden',
    'text-overflow': 'ellipsis'});

});