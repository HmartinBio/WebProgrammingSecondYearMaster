$(document).ready(function(){
    $("#username").css({'left': '88.5%', 
    'overflow': 'hidden',
    'text-overflow': 'ellipsis'});

    $(".firstQuestion").css({'position': 'absolute', 'top': '17%'});
    $(".secondQuestion").css({'position': 'absolute', 'top': '90%'});
    $(".thirdQuestion").css({'position': 'absolute', 'top': '165%'});
    $(".fourthQuestion").css({'position': 'absolute', 'top': '240%'});

    $("button[type='submit']").css({'position': 'absolute', 'top': '310%'});

});